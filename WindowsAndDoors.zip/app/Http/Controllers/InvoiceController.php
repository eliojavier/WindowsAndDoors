<?php

namespace App\Http\Controllers;

use App\Detail;
use App\Invoice;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class InvoiceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $invoices = Invoice::all();
        return view ('invoices.index', compact('invoices'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('invoices.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $invoice = new Invoice();
        $invoice->number = $request->number;
        $invoice->date = $request->date;
        $invoice->bill_to = $request->bill_to;
        $invoice->ship_to = $request->ship_to;
        $invoice->save();

        $total_items = sizeof($request->item_code);

        for ($i = 0; $i < $total_items; $i++) {
            $detail = new Detail();
            $detail->item_code = $request->item_code[$i];
            $detail->description = $request->description[$i];
            $detail->quantity = $request->quantity[$i];
            $detail->price_each = $request->price_each[$i];
            $detail->total_item = $request->quantity[$i] * $request->price_each[$i];

            $detail->invoice()->associate($invoice);
            $detail->save();
        }

        $total = 0;
        foreach($invoice->details as $detail){
            $total += $detail->total_item;
        }


        $invoice->file_path = 'invoices/'.$invoice->number.'.pdf';
        
        $pdf = PDF::loadView('invoices.pdf', compact('invoice', 'total'))->setPaper('a4', 'portrait');
        $pdf->save($invoice->file_path);
        
        $invoice->update();

        Mail::send(new \App\Mail\Invoice($invoice->number));

        return $pdf->save('invoices/'.$invoice->number.'.pdf')->stream('invoice.pdf');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Invoice $invoice
     * @return \Illuminate\Http\Response
     */
    public function show(Invoice $invoice)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Invoice $invoice
     * @return \Illuminate\Http\Response
     */
    public function edit(Invoice $invoice)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \App\Invoice $invoice
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Invoice $invoice)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Invoice $invoice
     * @return \Illuminate\Http\Response
     */
    public function destroy(Invoice $invoice)
    {
        //
    }
}
