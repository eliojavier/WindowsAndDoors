<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

    <link rel="stylesheet" href="css/bootstrap.css">
    <style>
        h1, h2, h3, h4, h5, h6, p {
            font-family: Raleway, 'sans-serif';
        }
        th {
            background-color: gainsboro;
            text-align: center;
        }
    </style>





<!-- Latest compiled and minified CSS -->
    
    
</head>

<body>
<div class="container">
    <div class="row">
        <div class="col-md-12 text-center">
            <h1><strong>INVOICE</strong></h1>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-md-12">
            <h4><strong>JJJ WINDOWS & DOORS <br>
                    INSTALLATION CORP</strong></h4>
            <p>9911 W OKEECHOBEE RD APT 510 <br>
                HIALEAH GARDENS, FL 33016</p>
        </div>
    </div>

    <br>

    <div class="row">
        <div class="col-md-12">
            <h4><strong>Invoice #: </strong> <?php echo e($invoice->number); ?></h4>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <h4><strong>Date: </strong> <?php echo e($invoice->date); ?></h4>
        </div>
    </div>

    <br><br>

    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>Bill to</th>
                    <th>Ship to</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td><?php echo html_entity_decode($invoice->bill_to); ?></td>
                    <td><?php echo html_entity_decode($invoice->ship_to); ?></td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>P.O. #</th>
                    <th>Rep</th>
                    <th>Ship</th>
                    <th>Via</th>
                    <th>F.O.B.</th>
                    <th>Project</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>Item-code</th>
                    <th>Description</th>
                    <th>Quantity</th>
                    <th>Price each</th>
                    <th>Amount</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $invoice->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($detail->item_code); ?></td>
                    <td><?php echo e($detail->description); ?></td>
                    <td><?php echo e($detail->quantity); ?></td>
                    <td><?php echo e($detail->price_each); ?></td>
                    <td><?php echo e($detail->total_item); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 text-right">
            <h4><strong>Total: </strong><?php echo e($total); ?></h4>
            <h3><strong>Balance due: </strong><?php echo e($total); ?></h3>
        </div>
    </div>
</div>
</body>
</html>
