<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('css/summernote.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-primary">
                    <div class="panel-heading text-center"><strong>Invoice data</strong></div>
                    <div class="panel-body">
                        <?php echo Form::open(['url' => 'admin/invoices']); ?>

                        <div class="row">
                            <div class="form-group col-md-6">
                                <?php echo Form::label('Invoice number', ''); ?>

                                <?php echo Form::text('number', old('number'), ['class' => 'form-control', 'placeholder' => 'Invoice number']); ?>

                            </div>
                            <div class="form-group col-md-6">
                                <?php echo Form::label('Date', ''); ?>

                                <?php echo Form::date('date', old('date'), ['class' => 'form-control']); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('Bill To', ''); ?>

                                    <?php echo Form::textarea('bill_to', old('bill_to'), ['class' => 'form-control', 'placeholder' => 'Bill to', 'id'=>'sn_bill_to']); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo Form::label('Ship To', ''); ?>

                                    <?php echo Form::textarea('ship_to', old('ship_to'), ['class' => 'form-control', 'placeholder' => 'Ship to', 'id'=>'sn_ship_to']); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <?php echo $__env->make('invoices._item-form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                        <div class="row" id="item-row">

                        </div>
                        <invoice-item></invoice-item>
                        <div class="form-group text-center">
                            <?php echo Form::submit('Aceptar', ['class'=>'btn btn-primary', 'type'=>'submit']); ?>

                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/summernote.min.js')); ?>"></script>
    
    <script>
        $('#sn_bill_to').summernote({
            toolbar: [
                ['style', ['bold', 'italic', 'underline', 'clear']]
            ],
            height: 150
        });
        $('#sn_ship_to').summernote({
            toolbar: [
                ['style', ['bold', 'italic', 'underline', 'clear']]
            ],
            height: 150
        });


        $('#add-row').click(function () {
            var elem ='<div class="col-md-3">' +
                    '<div class="form-group">' +
                    '<?php echo Form::label('Item code', ''); ?>' +
                    '<?php echo Form::text('item_code[]', '', ['class' => 'form-control']); ?>' +
                    '</div>' +
                    '</div>' +
                    '<div class="col-md-5">' +
                    '<div class="form-group">' +
                    '<?php echo Form::label('Description', ''); ?>' +
                    '<?php echo Form::text('description[]', '', ['class' => 'form-control']); ?>' +
                    '</div>' +
                    '</div>' +
                    '<div class="col-md-1">' +
                    '<div class="form-group">' +
                    '<?php echo Form::label('Quantity', ''); ?>' +
                    '<?php echo Form::text('quantity[]', '', ['class' => 'form-control']); ?>' +
                    '</div>' +
                    '</div>' +
                    '<div class="col-md-2">' +
                    '<div class="form-group">' +
                    '<?php echo Form::label('Price each', ''); ?>' +
                    '<?php echo Form::text('price_each[]', '', ['class' => 'form-control']); ?>' +
                    '</div>' +
                    '</div>';
            $('#item-row').append($(elem));
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>